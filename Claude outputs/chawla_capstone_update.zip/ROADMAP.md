# Vehicle Health Decision Engine — Fast-Track Roadmap

The 12-week plan from the strategy doc, compressed to **6 weeks** (Oct 26 – Dec 6, 2026). Week 0 is this weekend.

**Core hypothesis:** we can turn noisy telemetry into a trustworthy maintenance decision: Continue / Monitor / Inspect Soon / High Priority.
**Success test:** the engine beats simple threshold alerts on false alerts and detection lead time, and it explains why it decided what it did.

Roles: **R1** ML/Data · **R2** Backend · **R3** Frontend · **R4** Hardware/Integration · **R5** Product/Research

| Week | Dates | Goal | Deliverables | Owner |
|---|---|---|---|---|
| 0 | Oct 24–25 | Skeleton that works end to end | Repo, telemetry simulator, decision engine v0, threshold baseline, eval script, API + dashboard v0 | All (done in repo) |
| 1 | Oct 26–Nov 1 | Prove the problem + data | Interview script, competitor map, 5+ fleet interviews. Buy an ELM327 OBD-II adapter and log one real vehicle. Scania APS dataset audit. Lock the signal list | R5, R4, R1 |
| 2 | Nov 2–8 | Make the ML solid | Tune the engine on sim data. Isolation Forest vs z-score comparison. Scania benchmark (RF/XGBoost, cost-weighted metric). Interviews reach 10+ | R1, R5 |
| 3 | Nov 9–15 | Product-grade backend + UI | PostgreSQL storage, ingestion API, auth-lite. React dashboard (fleet list, vehicle page, evidence charts) | R2, R3 |
| 4 | Nov 16–22 | Real data | OBD logger → API pipeline. Engine on real logs. Robustness tests: noise, disconnects, frozen sensors | R4, R1, R2 |
| 5 | Nov 23–29 | Validation | Demo/pilot with 1 fleet operator. ROI estimate (downtime avoided vs price ₹199–399/vehicle/month) | R5, all |
| 6 | Nov 30–Dec 6 | Evidence + polish | Final evaluation report, capstone report, pitch deck, demo video | All |

## Checkpoints (go / no-go)
- **End of week 1:** at least 3 operators describe a real maintenance-prioritization pain, and we have a usable data source. If not → pivot the segment or data plan.
- **End of week 2:** the engine beats thresholds on false alerts and lead time. If not → say so honestly and fix the approach before building UI.
- **End of week 4:** the pipeline runs on real vehicle data, end to end.

## Rules
- Nothing goes in the MVP unless it helps prove the core hypothesis (see "What NOT to Build" in the strategy doc).
- Missing data = **DATA UNAVAILABLE**, never "healthy".
- Results on synthetic data are labelled as synthetic. The Scania benchmark ≠ real-world proof.
- Everyone codes. R5 owns customer evidence, not just slides.
