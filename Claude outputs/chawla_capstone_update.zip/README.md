# Vehicle Health Decision Engine

Turns noisy vehicle telemetry into one explainable decision per vehicle:
**Continue · Monitor · Inspect Soon · High Priority** (or **DATA UNAVAILABLE**, never "healthy" when data is missing).

See `ROADMAP.md` for the 6-week plan.

## Run it (Windows)
```powershell
cd "C:\projects masti\chawla capstone"
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt

python -m pytest -q                       # 15 tests
python -m eval.evaluate                   # engine vs thresholds -> results/eval_report.md
uvicorn backend.main:app --reload         # dashboard at http://127.0.0.1:8000
```
In the dashboard, click **Auto-play** or **+10 min** to watch faults develop. They start at 09:00 on the demo clock.

## How it decides
```
telemetry -> data quality (ranges, missing, frozen sensor)
          -> vehicle baseline (expected value for THIS vehicle given load/speed/ambient)
          -> z-score deviation per signal
          -> persistence (>=60% of last 5 min anomalous)
          -> multi-signal agreement
          -> risk + confidence -> decision + evidence
```
- 1 persistent signal → **Inspect Soon**. 2+ signals, or 1 extreme signal → **High Priority**
- Emerging (30–60% of window) or a degraded sensor → **Monitor**
- Less than 50% of the last 5 min has data → **DATA UNAVAILABLE**

All rules and limits are in `engine/config.py`.

## Layout
| Path | What |
|---|---|
| `engine/simulator.py` | Synthetic fleet with 10 labelled scenarios (pothole, hill climb, cooling fault, dropout…) |
| `engine/baseline.py` | Per-vehicle baseline model (fit on healthy history, save/load JSON) |
| `engine/engine.py` | Decision pipeline, explanations, threshold baseline for comparison |
| `eval/evaluate.py` | Fleet evaluation, clean + noisy conditions |
| `backend/main.py` | FastAPI: `/api/fleet`, `/api/vehicles/{id}`, `/api/telemetry`, `/api/vehicles/{id}/calibrate`, demo controls |
| `frontend/index.html` | Fleet dashboard (v0; React version in week 3) |
| `tools/import_obd.py` | OBD app log importer + calibrate/assess CLI |
| `docs/` | Interview script, interview log, competitor map |
| `tests/` | pytest |

## Current results (synthetic, 30 vehicles × 10 scenarios)
| | Engine | Thresholds |
|---|---|---|
| Faults detected | 100% | 78% |
| False alerts on benign trips | 1% | 39% |
| Median detection delay | 13 min | 63 min |
| Device dropout shown as DATA UNAVAILABLE | 100% | 0% |

These numbers come from synthetic data that is close to the model's structure, so treat them as an upper bound. Real OBD data (week 4) is the real test.

## Real car data (OBD-II)
1. Plug an ELM327 Bluetooth adapter into the car's OBD port. Log drives with **Torque Pro** or **Car Scanner** and export them as CSV into `logs/`.
2. Convert the logs and see which signals your car gives:
   `python -m tools.import_obd logs\drive1.csv --vehicle MYCAR`
3. Learn the car's normal behaviour from healthy drives (~1 h total is ideal):
   `python -m tools.import_obd logs\drive1.csv logs\drive2.csv --vehicle MYCAR --calibrate`
4. Assess any new drive:
   `python -m tools.import_obd logs\drive3.csv --vehicle MYCAR --assess`
5. Add `--push http://127.0.0.1:8000` to send it to the dashboard. Note that a dashboard reset wipes pushed vehicles.

Signals the car doesn't report (often vibration and ambient temp) are skipped automatically. Cold-start warm-up and engine-off rows are handled. Turn on the phone accelerometer logging in Torque to get vibration.

## Pushing data via API
```
POST /api/telemetry  {"vehicle_id": "MH12AB1234", "rows": [{"timestamp": "...", "speed": 42, "engine_load": 38,
                      "ambient_temp": 31, "coolant_temp": 89.5, "vibration": 0.41, "rpm": 1900, "battery_v": 14.1}]}
POST /api/vehicles/MH12AB1234/calibrate     # after ~1 h of healthy driving
```
